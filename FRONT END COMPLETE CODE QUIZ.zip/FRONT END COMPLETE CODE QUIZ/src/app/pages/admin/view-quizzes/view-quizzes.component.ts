import { Component, OnInit } from '@angular/core';
import { QuizService } from 'src/app/services/quiz.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-quizzes',
  templateUrl: './view-quizzes.component.html',
  styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {


  quizzes=[
     //just for testing
    //{
    //   qId:23,
    //   title:'Basic Java Quiz',
    //   description:'Java is Evergreen subject',
    //   maxMarks: '50',
    //   numberOfQuestions: '20',
    //   active:'',
    //   category:{
    //     title:'Programming'
    //   }
    // },

    // {
    //   qId:25,
    //   title:'Basic Java Quiz',
    //   description:'Java is Evergreen subject',
    //   maxMarks: '50',
    //   numberOfQuestions: '20',
    //   active:'',
    //   category:{
    //     title:'Programming'
    //   }
    // },
  ]
  constructor(private quiz:QuizService) { }

  ngOnInit(): void {

    this.quiz.quizzes().subscribe(
      (data:any)=>{
        this.quizzes=data;
        console.log(this.quizzes);
      },
      (error)=>{
        console.log(error);
        Swal.fire('Error !!','Error in Loading Data !','error')
      }
    );


  }

  //delete a quiz
  deleteQuiz(qId){
    //alert(qId);

    Swal.fire({
      icon: 'info',
      title:'Are you Sure?',
      confirmButtonText:'Delete',
      showCancelButton:true,

    }).then((result)=>{
      if(result.isConfirmed){
            //delete..

      this.quiz.deleteQuiz(qId).subscribe(
      (data:any)=>{
        this.quizzes=this.quizzes.filter((quiz)=>quiz.qid!=qId)
        Swal.fire('Success!!','Quiz Deleted Successfully','success');
      },
      (error)=>{
        Swal.fire('Error','Error while deleting the Quiz','error');
      });

      }
    });

 
  }

}
